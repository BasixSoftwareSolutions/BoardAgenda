Imports System.Data.SqlClient
Imports System.Data
Partial Class CommitteeMeetings
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sPath As String = "http://www.octa.net/AgendaPDF/"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim iCount As Integer
        Dim i As Integer

        Session("Page") = "CommitteeMeetings"

        If Not IsPostBack Then
            LoadCommittees()
            LoadGrid()
            iCount = DateDiff(DateInterval.Year, #1/1/2009#, Now())
            For i = 0 To iCount
                cboYear.Items.Insert(i, DatePart(DateInterval.Year, DateAdd(DateInterval.Year, -(i), Now())))
            Next
            cboYear.Items.Insert(0, "")
        End If

    End Sub

    Protected Sub LoadGrid()

        SqlDataSource1.SelectCommand = ""
        sSQL = "SELECT [CommitteeMeetingID], [CommitteeMeetingDate], "
        sSQL = sSQL & "CASE WHEN CommitteeMeetingCancelled = 1 THEN 'CANCELLED' END AS CommitteeMeetingCancelled, "
        sSQL = sSQL & "CommitteeMeetingType, "
        sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting, "
        sSQL = sSQL & "'" & sPath & "' + RTRIM(CONVERT(char(5), CommitteeMeetingID)) + '_Synopsis.pdf' AS Synopsis "
        sSQL = sSQL & "FROM [vwCommitteeMeetingDates] "
        'sSQL = sSQL & "WHERE DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & DateTime.Now.ToString("yyyy") & "' "
        sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
        SqlDataSource1.SelectCommand = sSQL
        txtSQL.Text = sSQL
        GridView1.DataSource = SqlDataSource1
        GridView1.DataBind()

    End Sub


    Protected Sub LoadCommittees()

        'Load the Committee dropdownbox
        sSQL = "SELECT [CommitteeMeetingTypeID], "
        sSQL = sSQL & "[CommitteeMeetingType] "
        sSQL = sSQL & "FROM [tblCommitteeMeetingType] "
        sSQL = sSQL & "WHERE([Active] = 1)"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        With cboCommittee
            .DataSource = oReader
            .DataTextField = "CommitteeMeetingType"
            .DataValueField = "CommitteeMeetingTypeID"
            .DataBind()
        End With

        oReader.Close()
        oConn.Close()

        'Reset dropdownbox to null
        cboCommittee.Items.Insert(0, "")

    End Sub

    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged

        If cboYear.SelectedIndex <> 0 Then
            SqlDataSource1.SelectCommand = ""
            sSQL = "SELECT [CommitteeMeetingID], [CommitteeMeetingDate], [CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN CommitteeMeetingCancelled = 1 THEN 'CANCELLED' END AS CommitteeMeetingCancelled, "
            sSQL = sSQL & "CommitteeMeetingType, "
            sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting, "
            sSQL = sSQL & "'" & sPath & "' + RTRIM(CONVERT(char(5), CommitteeMeetingID)) + '_Synopsis.pdf' AS Synopsis "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDates] "
            sSQL = sSQL & "WHERE DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & cboYear.SelectedItem.Text & "' "
            If cboMonth.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            End If
            If cboCommittee.Text <> "" Then
                sSQL = sSQL & "AND CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()
        Else
            SqlDataSource1.SelectCommand = ""
            sSQL = "SELECT [CommitteeMeetingID], [CommitteeMeetingDate], [CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN CommitteeMeetingCancelled = 1 THEN 'CANCELLED' END AS CommitteeMeetingCancelled, "
            sSQL = sSQL & "CommitteeMeetingType, "
            sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting, "
            sSQL = sSQL & "'" & sPath & "' + RTRIM(CONVERT(char(5), CommitteeMeetingID)) + '_Synopsis.pdf' AS Synopsis "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDates] "
            sSQL = sSQL & "WHERE [CommitteeMeetingDate] <= '" & DateTime.Now.Date & "' "
            If cboMonth.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            End If
            If cboCommittee.Text <> "" Then
                sSQL = sSQL & "AND CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()
        End If

    End Sub

    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged

        If cboMonth.Text <> 0 Then
            SqlDataSource1.SelectCommand = ""
            sSQL = "SELECT [CommitteeMeetingID], [CommitteeMeetingDate], [CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN CommitteeMeetingCancelled = 1 THEN 'CANCELLED' END AS CommitteeMeetingCancelled, "
            sSQL = sSQL & "CommitteeMeetingType, "
            sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting, "
            sSQL = sSQL & "'" & sPath & "' + RTRIM(CONVERT(char(5), CommitteeMeetingID)) + '_Synopsis.pdf' AS Synopsis "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDates] "
            sSQL = sSQL & "WHERE DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            If cboYear.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & cboYear.SelectedItem.Text & "' "
            End If
            If cboCommittee.Text <> "" Then
                sSQL = sSQL & "AND CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()

        End If
    End Sub

    Protected Sub cboCommittee_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCommittee.SelectedIndexChanged

        If cboCommittee.Text <> 0 Then
            sSQL = "SELECT [CommitteeMeetingID], [CommitteeMeetingDate], [CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN CommitteeMeetingCancelled = 1 THEN 'CANCELLED' END AS CommitteeMeetingCancelled, "
            sSQL = sSQL & "CommitteeMeetingType, "
            sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting, "
            sSQL = sSQL & "'" & sPath & "' + RTRIM(CONVERT(char(5), CommitteeMeetingID)) + '_Synopsis.pdf' AS Synopsis "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDates] "
            sSQL = sSQL & "WHERE  CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            If cboYear.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & cboYear.SelectedItem.Text & "' "
            End If
            If cboMonth.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()
        End If

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Function used to page datagrid
        GridView1.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        'Use the SQL staement stored in the txtSQL textbox
        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            GridView1.Visible = False
        Else
            GridView1.Visible = True
            GridView1.DataSource = oDataSet.tables.Item("dtRecordList")
            GridView1.DataBind()
        End If

    End Sub

    Protected Sub cmdReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReset.Click

        cboYear.SelectedIndex = 1
        cboMonth.SelectedIndex = 0
        cboCommittee.SelectedIndex = 0
        LoadGrid()

    End Sub

    Private Sub SortGrid(ByVal sSortField As String)

        'Sort function used to sort the data in the datagrid
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.tables("LoadRecords").DefaultView
        Source.Sort = sSortField

        GridView1.DataSource = Source
        GridView1.DataBind()

    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.Cells(4).Text = "CANCELLED" Then
                    e.Row.Enabled = False
                End If
            End If

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try
    End Sub

    Protected Sub GridView1_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles GridView1.Sorting

        SortGrid(e.SortExpression)

    End Sub
End Class
