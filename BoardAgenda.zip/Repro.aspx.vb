Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports System.Diagnostics

Partial Class Repro
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            LoadCommittees()
            LoadGrid()
            cboYear.Items.Insert(0, "")
            cboYear.Items.Insert(1, DateTime.Now.ToString("yyyy"))
            cboYear.Items.Insert(2, DatePart(DateInterval.Year, DateAdd(DateInterval.Year, -1, Now())))
            cboYear.Items.Insert(3, DatePart(DateInterval.Year, DateAdd(DateInterval.Year, -2, Now())))
            cboYear.Items.Insert(4, DatePart(DateInterval.Year, DateAdd(DateInterval.Year, -3, Now())))
            cboYear.Items.Insert(5, DatePart(DateInterval.Year, DateAdd(DateInterval.Year, -4, Now())))
        End If

        If Not Request("CommitteeMeetingID") = Nothing Then
            PopulateCommitteeLevel(Request.QueryString("CommitteeID"))
        End If
        MyTreeView.Attributes.Add("onclick", "OnCheckBoxCheckChanged(event)")

    End Sub

    Protected Sub LoadGrid()

        sSQL = "SELECT [CommitteeMeetingID], "
        sSQL = sSQL & "[CommitteeMeetingDate], "
        sSQL = sSQL & "CASE WHEN [CommitteeMeetingCancelled] = 1 THEN 'CANCELLED' END AS Cancelled, "
        sSQL = sSQL & "CommitteeMeetingType, "
        sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting "
        sSQL = sSQL & "FROM [vwCommitteeMeetingDatePreview] "
        sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
        txtSQL.Text = sSQL

        Try

            'Set the parameter values
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            If RcdCount = 0 Then
                GridView1.Visible = False
            Else
                GridView1.Visible = True
                GridView1.DataSource = oDataSet.Tables.Item("dtRecordList")
                GridView1.DataBind()
            End If

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try

    End Sub

    Protected Sub LoadCommittees()

        'Load the Route dropdownbox
        sSQL = "SELECT [CommitteeMeetingTypeID], "
        sSQL = sSQL & "[CommitteeMeetingType] "
        sSQL = sSQL & "FROM [tblCommitteeMeetingType] "
        sSQL = sSQL & "WHERE([Active] = 1)"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        With cboCommittee
            .DataSource = oReader
            .DataTextField = "CommitteeMeetingType"
            .DataValueField = "CommitteeMeetingTypeID"
            .DataBind()
        End With

        oReader.Close()
        oConn.Close()

        'Reset dropdownbox to null
        cboCommittee.Items.Insert(0, "")

    End Sub
    Protected Sub cboYear_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboYear.SelectedIndexChanged

        If cboYear.SelectedIndex <> 0 Then
            SqlDataSource1.SelectCommand = ""
            sSQL = "SELECT [CommitteeMeetingID], "
            sSQL = sSQL & "[CommitteeMeetingDate], "
            sSQL = sSQL & "[CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN [CommitteeMeetingCancelled] = 1 THEN 'CANCELLED' END AS Cancelled "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDatePreview] "
            sSQL = sSQL & "WHERE DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & cboYear.SelectedItem.Text & "' "
            If cboMonth.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            End If
            If cboCommittee.Text <> "" Then
                sSQL = sSQL & "AND CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()
        Else
            SqlDataSource1.SelectCommand = ""
            sSQL = "SELECT [CommitteeMeetingID], "
            sSQL = sSQL & "[CommitteeMeetingDate], "
            sSQL = sSQL & "[CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN [CommitteeMeetingCancelled] = 1 THEN 'CANCELLED' END AS Cancelled "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDatePreview] "
            sSQL = sSQL & "WHERE [CommitteeMeetingDate] <= '" & DateTime.Now.Date & "' "
            If cboMonth.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            End If
            If cboCommittee.Text <> "" Then
                sSQL = sSQL & "AND CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()
        End If

    End Sub

    Protected Sub cboMonth_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboMonth.SelectedIndexChanged

        If cboMonth.Text <> 0 Then
            SqlDataSource1.SelectCommand = ""
            sSQL = "SELECT [CommitteeMeetingID], "
            sSQL = sSQL & "[CommitteeMeetingDate], "
            sSQL = sSQL & "[CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN [CommitteeMeetingCancelled] = 1 THEN 'CANCELLED' END AS Cancelled "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDatePreview] "
            sSQL = sSQL & "WHERE DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            If cboYear.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & cboYear.SelectedItem.Text & "' "
            End If
            If cboCommittee.Text <> "" Then
                sSQL = sSQL & "AND CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()

        End If
    End Sub

    Protected Sub cboCommittee_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboCommittee.SelectedIndexChanged

        If cboCommittee.Text <> 0 Then
            sSQL = "SELECT [CommitteeMeetingID], "
            sSQL = sSQL & "[CommitteeMeetingDate], "
            sSQL = sSQL & "[CommitteeMeetingType], "
            sSQL = sSQL & "CASE WHEN [CommitteeMeetingCancelled] = 1 THEN 'CANCELLED' END AS Cancelled "
            sSQL = sSQL & "FROM [vwCommitteeMeetingDatePreview] "
            sSQL = sSQL & "WHERE  CommitteeMeetingType = '" & cboCommittee.SelectedItem.Text & "' "
            If cboYear.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Year, [CommitteeMeetingDate]) = '" & cboYear.SelectedItem.Text & "' "
            End If
            If cboMonth.Text <> "" Then
                sSQL = sSQL & "AND DatePart(DateInterval.Month, [CommitteeMeetingDate]) = " & cboMonth.SelectedItem.Value & " "
            End If
            sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
            SqlDataSource1.SelectCommand = sSQL
            txtSQL.Text = sSQL
            GridView1.DataSource = SqlDataSource1
            GridView1.DataBind()
        End If

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Function used to page datagrid
        GridView1.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        'Use the SQL staement stored in the txtSQL textbox
        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            GridView1.Visible = False
        Else
            GridView1.Visible = True
            GridView1.DataSource = oDataSet.Tables.Item("dtRecordList")
            GridView1.DataBind()
        End If

    End Sub

    Protected Sub cmdReset_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdReset.Click

        cboYear.SelectedIndex = 1
        cboMonth.SelectedIndex = 0
        cboCommittee.SelectedIndex = 0
        LoadGrid()
        MyTreeView.Nodes.Clear()

    End Sub

    Private Sub SortGrid(ByVal sSortField As String)

        'Sort function used to sort the data in the datagrid
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.Tables("LoadRecords").DefaultView
        Source.Sort = sSortField

        GridView1.DataSource = Source
        GridView1.DataBind()

    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Try
            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.Cells(5).Text = "CANCELLED" Then
                    e.Row.Enabled = False
                End If
            End If

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try
    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView1.SelectedIndexChanged

        MyTreeView.Nodes.Clear()
        PopulateCommitteeLevel(GridView1.SelectedDataKey.Value)
        cmdCheckSelectNode.Visible = True

    End Sub

    Protected Sub GridView1_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles GridView1.Sorting

        SortGrid(e.SortExpression)

    End Sub
    '*************************************************************************************************************
    Private Sub PopulateCommitteeLevel(ByVal iCommitteeID As Integer)

        sSQL = "SELECT DISTINCT CommitteeMeetingID, Meeting, CommitteeMeetingDate "
        If GridView1.SelectedDataKey.Values(1) = "Board Meeting" Then
            sSQL = sSQL & "FROM vwAgendaDocumentsBoardTreeView "
        Else
            sSQL = sSQL & "FROM vwAgendaDocumentsTreeView "
        End If
        sSQL = sSQL & "WHERE CommitteeMeetingID = " & iCommitteeID & " "
        sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")

        Dim da As New SqlDataAdapter(sSQL, sConn)
        Dim dt As New DataTable()
        da.Fill(dt)

        PopulateCommitteeNodes(dt, MyTreeView.Nodes)
    End Sub
    Private Sub PopulateCommitteeNodes(ByVal dt As DataTable, ByVal nodes As TreeNodeCollection)

        For Each dr As DataRow In dt.Rows
            Dim tn As New TreeNode()
            'Add Committee Metting
            tn.Text = dr("Meeting").ToString()
            tn.Value = dr("CommitteeMeetingID").ToString()
            tn.PopulateOnDemand = True
            tn.ShowCheckBox = True
            tn.SelectAction = TreeNodeSelectAction.SelectExpand
            tn.Expanded = True
            nodes.Add(tn)
        Next

    End Sub
    Private Sub PopulateItemLevel(ByVal parentid As Integer, ByVal parentNode As TreeNode)

        sSQL = "select DISTINCT AgendaReportID, CommitteeMeetingID, Title, AgendaItemNumber, BoardAgendaItemNumber"
        If GridView1.SelectedDataKey.Values(1) = "Board Meeting" Then
            sSQL = sSQL & ", Transmittal FROM vwAgendaDocumentsBoardTreeView "
            sSQL = sSQL & "WHERE CommitteeMeetingID=@parentID ORDER BY BoardAgendaItemNumber"
        Else
            sSQL = sSQL & " FROM vwAgendaDocumentsTreeView "
            sSQL = sSQL & "WHERE CommitteeMeetingID=@parentID ORDER BY AgendaItemNumber"
        End If

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim objCommand As New SqlCommand(sSQL, oConn)
        objCommand.Parameters.Add("@parentID", SqlDbType.Int).Value = parentid

        Dim da As New SqlDataAdapter(objCommand)
        Dim dt As New DataTable()

        da.Fill(dt)
        PopulateItemNodes(dt, parentNode.ChildNodes, parentid)

    End Sub
    Private Sub PopulateItemNodes(ByVal dt As DataTable, ByVal nodes As TreeNodeCollection, ByVal iCommitteeID As Integer)
        Dim sNavigateUrl As String
        sNavigateUrl = System.Configuration.ConfigurationManager.AppSettings("NavigateUrl")

        Dim tn1 As New TreeNode()
        'Add Synopsis
        tn1.Text = "Synopsis"
        tn1.Value = iCommitteeID
        tn1.NavigateUrl = sNavigateUrl & tn1.Value & "_Synopsis.pdf"
        tn1.Target = "_blank"
        tn1.ShowCheckBox = True
        tn1.SelectAction = TreeNodeSelectAction.SelectExpand
        nodes.Add(tn1)

        Dim tn2 As New TreeNode()
        'Add Minutes
        tn2.Text = "Minutes"
        tn2.Value = iCommitteeID
        tn2.NavigateUrl = sNavigateUrl & tn2.Value & "_Minutes.pdf"
        tn2.Target = "_blank"
        tn2.ShowCheckBox = True
        tn2.SelectAction = TreeNodeSelectAction.SelectExpand
        nodes.Add(tn2)

        For Each dr As DataRow In dt.Rows
            Dim tn As New TreeNode()
            'Add Items
            tn.Text = dr("Title").ToString()
            tn.Value = dr("AgendaReportID").ToString()
            tn.NavigateUrl = sNavigateUrl & tn.Value & "_Staff Report.pdf"
            tn.Target = "_blank"
            tn.PopulateOnDemand = True
            tn.ShowCheckBox = True
            tn.SelectAction = TreeNodeSelectAction.SelectExpand
            tn.Expanded = True
            nodes.Add(tn)
        Next

    End Sub
    Private Sub PopulateAttachmentLevel(ByVal parentid As Integer, ByVal parentNode As TreeNode)

        sSQL = "SELECT DISTINCT AgendaReportID, AttachmentID, CommitteeMeetingID, AttachmentName, DisplayName, DisplayOrder, DocURL, "

        If GridView1.SelectedDataKey.Values(1) = "Board Meeting" Then
            sSQL = sSQL & "(select count(*) FROM vwAgendaDocumentsBoardTreeView WHERE AgendaReportID=sc.AgendaReportID) childnodecount"
            sSQL = sSQL & ", Transmittal FROM vwAgendaDocumentsBoardTreeView sc "
        Else
            sSQL = sSQL & "(select count(*) FROM vwAgendaDocumentsTreeView WHERE AgendaReportID=sc.AgendaReportID) childnodecount"
            sSQL = sSQL & " FROM vwAgendaDocumentsTreeView sc "
        End If
        sSQL = sSQL & "WHERE AgendaReportID=@parentID "
        sSQL = sSQL & "ORDER BY DisplayOrder"
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim objCommand As New SqlCommand(sSQL, oConn)
        objCommand.Parameters.Add("@parentID", SqlDbType.Int).Value = parentid

        Dim da As New SqlDataAdapter(objCommand)
        Dim dt As New DataTable()

        da.Fill(dt)
        PopulateAttachemntNodes(dt, parentNode.ChildNodes)

    End Sub
    Private Sub PopulateAttachemntNodes(ByVal dt As DataTable, ByVal nodes As TreeNodeCollection)
        Dim sStr As String
        Dim sNavigateUrl As String
        sNavigateUrl = System.Configuration.ConfigurationManager.AppSettings("NavigateUrl")

        If GridView1.SelectedDataKey.Values(1) = "Board Meeting" Then
            For Each dr As DataRow In dt.Rows
                If (dr("Transmittal")) Is DBNull.Value Then Exit Sub
                If Not (dr("Transmittal")) Then Exit For
                Dim tn1 As New TreeNode()
                tn1.Text = "Transmittal"
                tn1.Value = Trim(dr("AgendaReportID")) & "_Transmittal.pdf"
                tn1.NavigateUrl = sNavigateUrl & tn1.Value
                tn1.Target = "_blank"
                tn1.ShowCheckBox = True
                nodes.Add(tn1)
                Exit For
            Next
        End If

        For Each dr As DataRow In dt.Rows
            Dim tn As New TreeNode()
            If dr("DisplayName") Is DBNull.Value Then
                If dr("AttachmentName") Is DBNull.Value Then
                    GoTo NoAttachment
                Else
                    sStr = RTrim(dr("AttachmentName")).ToString()
                End If
            Else
                sStr = RTrim(dr("DisplayName")).ToString()
            End If
            tn.Text = sStr
            tn.Value = Trim(dr("AgendaReportID")) & "_" & sStr & ".pdf"
            tn.NavigateUrl = sNavigateUrl & tn.Value
            tn.Target = "_blank"
            tn.ShowCheckBox = True
            nodes.Add(tn)
NoAttachment:
        Next
    End Sub

    Protected Sub MyTreeView_TreeNodeExpanded(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles MyTreeView.TreeNodeExpanded

        If e.Node.Parent Is Nothing Then
            For Each node As TreeNode In (CType(sender, TreeView)).Nodes
                If Not (node.Equals(e.Node)) Then
                    node.Expand()
                End If
            Next
            Return
        End If

        Dim tn As TreeNode = e.Node.Parent
        For Each node As TreeNode In tn.ChildNodes
            If Not (node.Equals(e.Node)) Then
                node.ExpandAll()
            End If
        Next

    End Sub

    Protected Sub MyTreeView_TreeNodePopulate(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.TreeNodeEventArgs) Handles MyTreeView.TreeNodePopulate

        If e.Node.Depth = 0 Then
            PopulateItemLevel(CInt(e.Node.Value), e.Node)
        Else
            PopulateAttachmentLevel(CInt(e.Node.Value), e.Node)
        End If

    End Sub

    Protected Sub cmdCheckSelectNode_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCheckSelectNode.Click
        Dim sMsg As String
        Dim sPath As String
        Dim sPDF As String
        Dim sMergePath As String

        sMsg = ""
        sPDF = ""
        sPath = System.Configuration.ConfigurationManager.AppSettings("PDFDocFilePath")

        If MyTreeView.CheckedNodes.Count > 0 Then
            'Display the selected documents
            For Each node As TreeNode In MyTreeView.CheckedNodes
                If node.Depth = 1 Then
                    If node.Text = "Minutes" Or node.Text = "Synopsis" Then
                        sPDF = sPDF & "" & sPath & node.Value & "_" & node.Text & ".pdf+"
                    End If
                End If
                If node.Depth > 1 Then
                    sMsg = sMsg & node.Value & "_" & node.Text & "" & Chr(10) & Chr(13)
                    sPDF = sPDF & "" & sPath & node.Value & "+"
                End If
            Next
            sPDF = Left(sPDF, (Len(sPDF) - 1))
        Else
            lblShowMessage.Text = "Sorry! You didnt select any records"
            Exit Sub
        End If

        sMergePath = System.Configuration.ConfigurationManager.AppSettings("MergeFilePath")
        SaveTextToFile(sPDF, sMergePath)
        RegisterJScript()

    End Sub

    Private Sub RegisterJScript()
        Dim sJScript As String

        sJScript = "<script language=javascript> "
        sJScript = sJScript & "newwin=window.open('AgendaPackage.aspx','_blank','left=5,top=5,toolbar=false,status=false,directories=false,menubar=false,scrollbars=false,resizable=yes,copyhistory=false,width=600,height=700'); "
        sJScript = sJScript & "</scr" & "ipt>"
        ClientScript.RegisterClientScriptBlock(GetType(Repro), "NewWin", sJScript)

    End Sub
    Public Function SaveTextToFile(ByVal strData As String, ByVal FullPath As String, Optional ByVal ErrInfo As String = "") As Boolean

        Dim bAns As Boolean = False
        Dim objReader As StreamWriter
        Try
            objReader = New StreamWriter(FullPath)
            objReader.Write(strData)
            objReader.Close()
            bAns = True
        Catch Ex As Exception
            ErrInfo = Ex.Message

        End Try
        Return bAns
    End Function
End Class
