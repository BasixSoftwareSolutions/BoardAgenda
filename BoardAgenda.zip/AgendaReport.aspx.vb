Imports System.Data.SqlClient
Imports System.Data

Partial Class AgendaReport
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Session("Page") = "Attachment" Then
                Session("Page") = "AgendaItem"
            Else
                Session("Page") = "AgendaItem"
                Session("CommitteeID") = Request.QueryString("CommitteeID")
                Session("CommitteeMeeting") = Request.QueryString("CommitteeMeeting")
            End If

            If Request.QueryString("CommitteeMeetingType") = "Board Meeting" Then
                LoadBoardData(Request.QueryString("CommitteeID"))
                LoadBoardRecord()
                pnlCommitteeNoticeContent.visible=false
                pnlCommitteeNoticeTitle.visible=false
                pnlBoardNoticeTitle.visible=true
                pnlBoardNoticeContent.Visible = True
                lblPublicCommentNumber.Visible = False
                lblPublicComments.Visible = False
            Else
                LoadCommitteeData(Request.QueryString("CommitteeID"))
                LoadCommitteeRecord()
                pnlCommitteeNoticeContent.visible=true
                pnlCommitteeNoticeTitle.visible=true
                pnlBoardNoticeTitle.visible=false
                pnlBoardNoticeContent.Visible = False
                lblPublicCommentNumber.Visible = True
                lblPublicComments.Visible = True
            End If
        End If

    End Sub

    Private Sub LoadBoardRecord()
        'Load the record
        Dim sStr As String
        Dim dNextDate As Date
        Dim iCount As Integer

        sSQL = "SELECT * FROM vwAgendaReport WHERE CommitteeMeetingID = " & Request.QueryString("CommitteeID")
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            'Session("RecordID") = CInt(Request.QueryString("ID"))
            If Not IsDBNull(dr("MeetingDayTime")) Then
                lblDateTime.Text = dr("MeetingDayTime")
            End If

            If Not IsDBNull(dr("CommitteeMeetingType")) Then
                lblCommitteeName.Text = dr("CommitteeMeetingType")
            End If

            If Not IsDBNull(dr("PledgeName")) Then
                lblPledgeName.Text = dr("PledgeName")
            End If

            If Not IsDBNull(dr("InvocationName")) Then
                lblInvocation.Text = dr("InvocationName")
            End If

            'If Not IsDBNull(dr("CommitteeMeetingMinutesDate")) Then
            'lblApprovalOfMinutes.Text = "Of the " & Format(dr("CommitteeMeetingMinutesDate"), "MMM d, yyyy") & ", " & dr("CommitteeMeetingTypeReportDisplay") & " Committee meeting."
            'End If

            dNextDate = DateAdd(DateInterval.Month, 1, dr("CommitteeMeetingDateFormated"))
            sStr = "The next regularly scheduled meeting of this Board will be held at "
            sStr = sStr & "9:00 a.m. on " & dNextDate.ToString("MMM d, yyyy") & " at the OCTA Headquarters."
            lblAdjourmentText.Text = sStr

            If IsDBNull(dr("InvocationID")) Then
                lblInvocationHeader.Visible = False
                lblInvocation.Visible = False
            End If

            If IsDBNull(dr("PledgeOfAllegianceID")) Then
                lblPledgeHeader.Visible = False
                lblPledgeName.Visible = False
            End If

        Loop

        oConn.Close()
        dr.Close()
        oComm = Nothing

        iCount = GetSpecialMattersCount("Board", Request.QueryString("CommitteeID"))
        iCount = GetConsentCalendarCount("Board", Request.QueryString("CommitteeID"))
        iCount = GetItemCount("Board", Request.QueryString("CommitteeID"))

        lblCEOReportItemNumber.Text = (iCount + 1).ToString & "."
        lblCMReport.Text = (iCount + 2).ToString & "."
        lblClosedSessionItemNumber.Text = (iCount + 3).ToString & "."
        lblAdjournment.Text = (iCount + 4).ToString & "."

    End Sub

    Private Sub LoadCommitteeRecord()
        'Load the record
        Dim sStr As String
        Dim dNextDate As Date
        Dim iCount As Integer

        sSQL = "SELECT * FROM vwAgendaReport WHERE CommitteeMeetingID = " & Request.QueryString("CommitteeID")
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            'Session("RecordID") = CInt(Request.QueryString("ID"))
            If Not IsDBNull(dr("MeetingDayTime")) Then
                lblDateTime.Text = dr("MeetingDayTime")
            End If

            If Not IsDBNull(dr("CommitteeMeetingType")) Then
                lblCommitteeName.Text = dr("CommitteeMeetingType")
            End If

            If Not IsDBNull(dr("PledgeName")) Then
                lblPledgeName.Text = dr("PledgeName")
            End If

            If Not IsDBNull(dr("InvocationName")) Then
                lblInvocation.Text = dr("InvocationName")
            End If

            'If Not IsDBNull(dr("CommitteeMeetingMinutesDate")) Then
            'lblApprovalOfMinutes.Text = "Of the " & Format(dr("CommitteeMeetingMinutesDate"), "MMM d, yyyy") & ", " & dr("CommitteeMeetingTypeReportDisplay") & " Committee meeting."
            'End If

            dNextDate = DateAdd(DateInterval.Month, 1, dr("CommitteeMeetingDateFormated"))
            sStr = "The next regularly scheduled meeting of this Committee will be held at "
            sStr = sStr & "9:00 a.m. on " & dNextDate.ToString("MMM d, yyyy") & " at the OCTA Headquarters."
            lblAdjourmentText.Text = sStr

            If IsDBNull(dr("InvocationID")) Then
                lblInvocationHeader.Visible = False
                lblInvocation.Visible = False
            End If

            If IsDBNull(dr("PledgeOfAllegianceID")) Then
                lblPledgeHeader.Visible = False
                lblPledgeName.Visible = False
            End If

        Loop

        oConn.Close()
        dr.Close()
        oComm = Nothing

        iCount = GetSpecialMattersCount("Committee", Request.QueryString("CommitteeID"))
        iCount = GetConsentCalendarCount("Committee", Request.QueryString("CommitteeID"))
        iCount = GetItemCount("Committee", Request.QueryString("CommitteeID"))

        lblCEOReportItemNumber.Text = (iCount + 1).ToString & "."
        lblCMReport.Text = (iCount + 2).ToString & "."
        lblClosedSessionItemNumber.Text = (iCount + 3).ToString & "."
        lblAdjournment.Text = (iCount + 4).ToString & "."


    End Sub

    Protected Sub rRegularCalendar_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rRegularCalendar.ItemDataBound

        If rRegularCalendar.Items.Count < 1 Then
            If e.Item.ItemType = ListItemType.Footer Then
                Dim lblFooter As Label = CType(e.Item.FindControl("lblEmptyDataRegular"), Label)
                lblFooter.Visible = True
            End If
        End If

    End Sub

    Protected Sub rDiscussionItems_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rDiscussionItems.ItemDataBound

        If rDiscussionItems.Items.Count < 1 Then
            If e.Item.ItemType = ListItemType.Footer Then
                Dim lblFooter As Label = CType(e.Item.FindControl("lblEmptyDataDiscussion"), Label)
                lblFooter.Visible = True
            End If
        End If

    End Sub

    Protected Sub rSpecialCalendar_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rSpecialCalendar.ItemDataBound

        If rSpecialCalendar.Items.Count < 1 Then
            If e.Item.ItemType = ListItemType.Footer Then
                Dim lblFooter As Label = CType(e.Item.FindControl("lblEmptyDataSpecial"), Label)
                lblFooter.Visible = True
            End If
        End If

    End Sub

    Public Function GetSpecialMattersCount(ByVal sMeetingType As String, ByVal iCommitteeID As Integer) As Integer
        Dim sCriteria As String
        Dim iCount As Integer

        'Set the Special Calendar Section
        If sMeetingType = "Committee" Then
            sCriteria = "[AssignedToCommitteeID] = " & iCommitteeID & " and [CommitteeCatagoryID] = 1"
            sCriteria = sCriteria & " AND [Deleted] = 0"
        Else
            sCriteria = "[AssignedToBoardID] = " & iCommitteeID & " and [BoardCatagoryID] = 1"
            sCriteria = sCriteria & " AND [Deleted] = 0"
        End If

        sSQL = "SELECT Count(*) AS SpecialCount FROM tblAgendaReport WHERE " & sCriteria
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            iCount = dr("SpecialCount")
        Loop
        dr.Close()

        If iCount = 0 Then 'Don't display record count
            GetSpecialMattersCount = 0
            oConn.Close()
            dr.Close()
            oComm = Nothing
            Exit Function
        ElseIf iCount > 0 Then
            If sMeetingType = "Committee" Then
                sSQL = "SELECT max(AgendaItemNumber) FROM tblAgendaReport WHERE " & sCriteria
            Else
                sSQL = "SELECT max(BoardAgendaItemNumber) FROM tblAgendaReport WHERE " & sCriteria
            End If
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
            oComm.CommandType = CommandType.Text

            dr = oComm.ExecuteReader()

            'Check each field for null values 
            Do While dr.Read()
                iCount = dr(0)
            Loop

            oConn.Close()
            dr.Close()
            oComm = Nothing
            lblApprovalMinutesNumber.Text = (iCount + 1) & "."
            End If

    End Function

    Public Function GetConsentCalendarCount(ByVal sMeetingType As String, ByVal iCommitteeID As Integer) As Integer
        Dim sCriteria As String
        Dim iCount As Integer
        Dim iMin As Integer
        Dim iMax As Integer

        'Set the Consent Calendar Section
        If sMeetingType = "Committee" Then
            sCriteria = "[AssignedToCommitteeID] = " & iCommitteeID & " and [CommitteeCatagoryID] = 2"
            sCriteria = sCriteria & " AND [Deleted] = 0"
        Else
            sCriteria = "[AssignedToBoardID] = " & iCommitteeID & " and [BoardCatagoryID] = 2"
            sCriteria = sCriteria & " AND [Deleted] = 0"
        End If

        sSQL = "SELECT Count(*) AS ConsentCount FROM tblAgendaReport WHERE " & sCriteria
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            iCount = dr("ConsentCount")
        Loop

        If iCount = 0 Then
            iMin = CInt(Left((0 & lblApprovalMinutesNumber.Text), 1))
            lblConsent.Text = "Consent Calendar  (Item " & iMin & ")"
        ElseIf iCount > 0 Then
            iMin = CInt(0 & lblApprovalMinutesNumber.Text)
            iMax = iMin + iCount
            lblConsent.Text = "Consent Calendar  (Items " & iMin & " through " & iMax & ")"
        End If

        oConn.Close()
        dr.Close()
        oComm = Nothing

    End Function

    Public Function GetItemCount(ByVal sMeetingType As String, ByVal iCommitteeID As Integer) As Integer
        Dim sCriteria As String
        Dim iCount As Integer

        'Set the Consent Calendar Section
        If sMeetingType = "Committee" Then
            sCriteria = "[AssignedToCommitteeID] = " & iCommitteeID & ""
            sCriteria = sCriteria & " AND [Deleted] = 0"
        Else
            sCriteria = "[AssignedToBoardID] = " & iCommitteeID & ""
            sCriteria = sCriteria & " AND [Deleted] = 0"
        End If

        If sMeetingType = "Committee" Then
            sSQL = "SELECT MAX(AgendaItemNumber) AS MaxItemNumber FROM tblAgendaReport WHERE " & sCriteria
        Else
            sSQL = "SELECT MAX(BoardAgendaItemNumber) AS MaxItemNumber FROM tblAgendaReport WHERE " & sCriteria
        End If

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            If dr("MaxItemNumber") IsNot DBNull.Value Then
                iCount = dr("MaxItemNumber")
            Else
                iCount = 0
            End If

        Loop

        If iCount = 0 Then
            GetItemCount = 2
        ElseIf iCount > 0 Then
            GetItemCount = iCount
        End If

        oConn.Close()
        dr.Close()
        oComm = Nothing

    End Function
    Public Function GetNextMeeting(ByVal iID As Integer) As Date

        sSQL = "Select MIN(CommitteeMeetingID), CommitteeMeetingDate "
        sSQL = sSQL & "FROM dbo.tblCommitteeMeetings "
        sSQL = sSQL & "WHERE(CommitteeMeetingTypeID = 1) "
        sSQL = sSQL & "AND tblCommitteeMeetings.CommitteeMeetingID > " & iID & ""


        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            If Not IsDBNull(dr("NextCommitteeDate")) Then
                GetNextMeeting = dr("NextCommitteeDate")
            End If
        Loop

        oConn.Close()
        dr.Close()
        oComm = Nothing

    End Function

    Public Sub GetMeetingMinutesLink(ByVal iID As Integer)

        sSQL = "Select MAX(CommitteeMeetingID) AS PrevCommitteeID "
        sSQL = sSQL & "FROM dbo.tblCommitteeMeetings "
        sSQL = sSQL & "WHERE(CommitteeMeetingTypeID = CommitteeMeetingTypeID) "
        sSQL = sSQL & "AND tblCommitteeMeetings.CommitteeMeetingID < " & iID & ""


        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        'Check each field for null values 
        Do While dr.Read()
            If Not IsDBNull(dr("PrevCommitteeID")) Then
                'hlPreviousMinutes.NavigateUrl = "\\OCTANT14\ShareApp\StaffReport\Test\MasterFiles\" & dr("PrevCommitteeID") & "_Minutes.pdf"
            End If
        Loop

        oConn.Close()
        dr.Close()
        oComm = Nothing

    End Sub

    Public Sub LoadBoardData(ByVal iCommitteeID As Integer)

        'sdsSpecialCalendar:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.BoardAgendaItemNumber AS AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToBoardID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems, "
        sSQL = sSQL & "CASE WHEN (SELECT COUNT(*) FROM tblAttachments "
        sSQL = sSQL & "WHERE tblAttachments.AgendaReportID = tblAgendaReport.AgendaReportID) > 0 THEN "
        sSQL = sSQL & "'Y' ELSE 'N' END AS Attachments "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.ToBoard = 1) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToBoardID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.BoardCatagoryID = 1) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.BoardAgendaItemNumber"

        sdsSpecialCalendar.SelectCommand = sSQL

        'sdsConsentCalendar:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.BoardAgendaItemNumber AS AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.AgendaItemNumber AS CommitteeAgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToBoardID, "
        sSQL = sSQL & "tblAgendaReport.AssignedToCommitteeID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "CASE WHEN tblAgendaReport.ReportTitle = 'Approval of Minutes' THEN 'Y' ELSE 'N' END AS ApprovalOfMinutes, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems, "
        sSQL = sSQL & "CASE WHEN (SELECT COUNT(*) FROM tblAttachments "
        sSQL = sSQL & "WHERE tblAttachments.AgendaReportID = tblAgendaReport.AgendaReportID) > 0 THEN "
        sSQL = sSQL & "'Y' ELSE 'N' END AS Attachments, "
        sSQL = sSQL & "'Y' AS IsBoardMeeting "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.ToBoard = 1) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToBoardID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.BoardCatagoryID = 2) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.BoardAgendaItemNumber"

        sdsConsentCalendar.SelectCommand = sSQL

        'sdsRegularCalendar:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.BoardAgendaItemNumber AS AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToBoardID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems, "
        sSQL = sSQL & "CASE WHEN (SELECT COUNT(*) FROM tblAttachments "
        sSQL = sSQL & "WHERE tblAttachments.AgendaReportID = tblAgendaReport.AgendaReportID) > 0 THEN "
        sSQL = sSQL & "'Y' ELSE 'N' END AS Attachments, "
        sSQL = sSQL & "'Y' AS IsBoardMeeting "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.ToBoard = 1) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToBoardID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.BoardCatagoryID = 3) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.BoardAgendaItemNumber"

        sdsRegularCalendar.SelectCommand = sSQL

        'sdsDiscussionItems:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.BoardAgendaItemNumber AS AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToBoardID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.ToBoard = 1) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToBoardID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.BoardCatagoryID = 4) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.BoardAgendaItemNumber"

        sdsDiscussionItems.SelectCommand = sSQL

        'sdsClosedSession:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.BoardAgendaItemNumber AS AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToBoardID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.ToBoard = 1) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToBoardID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.BoardCatagoryID = 5) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.BoardAgendaItemNumber"

        sdsClosedSession.SelectCommand = sSQL

    End Sub

    Public Sub LoadCommitteeData(ByVal iCommitteeID As Integer)

        'sdsSpecialCalendar:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToCommitteeID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems, "
        sSQL = sSQL & "CASE WHEN (SELECT COUNT(*) FROM tblAttachments "
        sSQL = sSQL & "WHERE tblAttachments.AgendaReportID = tblAgendaReport.AgendaReportID) > 0 THEN "
        sSQL = sSQL & "'Y' ELSE 'N' END AS Attachments "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToCommitteeID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.CommitteeCatagoryID = 1) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.AgendaItemNumber"

        sdsSpecialCalendar.SelectCommand = sSQL

        'sdsConsentCalendar:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToCommitteeID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "CASE WHEN tblAgendaReport.ReportTitle = 'Approval of Minutes' THEN 'Y' ELSE 'N' END AS ApprovalOfMinutes, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems, "
        sSQL = sSQL & "CASE WHEN (SELECT COUNT(*) FROM tblAttachments "
        sSQL = sSQL & "WHERE tblAttachments.AgendaReportID = tblAgendaReport.AgendaReportID) > 0 THEN "
        sSQL = sSQL & "'Y' ELSE 'N' END AS Attachments, "
        sSQL = sSQL & "'N' AS IsBoardMeeting "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToCommitteeID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.CommitteeCatagoryID = 2) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.AgendaItemNumber"

        sdsConsentCalendar.SelectCommand = sSQL

        'sdsRegularCalendar:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToCommitteeID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems, "
        sSQL = sSQL & "CASE WHEN (SELECT COUNT(*) FROM tblAttachments "
        sSQL = sSQL & "WHERE tblAttachments.AgendaReportID = tblAgendaReport.AgendaReportID) > 0 THEN "
        sSQL = sSQL & "'Y' ELSE 'N' END AS Attachments, "
        sSQL = sSQL & "'N' AS IsBoardMeeting "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToCommitteeID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.CommitteeCatagoryID = 3) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.AgendaItemNumber"

        sdsRegularCalendar.SelectCommand = sSQL

        'sdsDiscussionItems:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToCommitteeID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToCommitteeID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.CommitteeCatagoryID = 4) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.AgendaItemNumber"

        sdsDiscussionItems.SelectCommand = sSQL

        'sdsClosedSession:
        sSQL = "SELECT TOP 100 PERCENT tblAgendaReport.AgendaReportID, "
        sSQL = sSQL & "tblAgendaReport.AgendaItemNumber, "
        sSQL = sSQL & "tblAgendaReport.ItemOrder, "
        sSQL = sSQL & "tblAgendaReport.AssignedToCommitteeID, "
        sSQL = sSQL & "tblAgendaReport.ReportTitle, "
        sSQL = sSQL & "tblAuthors.AuthorName AS MainAuthorName, "
        sSQL = sSQL & "tblAuthors_1.AuthorName AS CoAuthorName, "
        sSQL = sSQL & "tblDivision.DivisionDirector, "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "CASE WHEN NOT (tblAuthors_1.AuthorName) IS NULL THEN "
        sSQL = sSQL & "tblAuthors_1.AuthorName + '/' ELSE '' END + "
        sSQL = sSQL & "tblDivision.DivisionDirector AS Author, "
        sSQL = sSQL & "tblAgendaReport.ReportOverview, "
        sSQL = sSQL & "tblAgendaReport.Recommendations, "
        sSQL = sSQL & "tblAgendaReport.CommitteeCatagoryID, "
        sSQL = sSQL & "tblAgendaReport.NumOfTravelItems "
        sSQL = sSQL & "FROM tblAuthors LEFT OUTER JOIN "
        sSQL = sSQL & "tblDivision ON tblAuthors.DivisionID = tblDivision.DivisionID "
        sSQL = sSQL & "RIGHT OUTER JOIN tblAgendaReport "
        sSQL = sSQL & "LEFT OUTER JOIN tblAuthors AS tblAuthors_1 ON "
        sSQL = sSQL & "tblAgendaReport.CoAuthor = tblAuthors_1.AuthorID ON "
        sSQL = sSQL & "tblAuthors.AuthorID = tblAgendaReport.Author "
        sSQL = sSQL & "WHERE (tblAgendaReport.Deleted = 0) "
        sSQL = sSQL & "AND (tblAgendaReport.AssignedToCommitteeID = " & iCommitteeID & ") "
        sSQL = sSQL & "AND (tblAgendaReport.CommitteeCatagoryID = 5) "
        sSQL = sSQL & "ORDER BY tblAgendaReport.AgendaItemNumber"

        sdsClosedSession.SelectCommand = sSQL

    End Sub

    Protected Sub rClosedSession_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rClosedSession.ItemDataBound

        'If rClosedSession.Items.Count < 1 Then
        'If e.Item.ItemType = ListItemType.Footer Then
        'Dim lblFooter As Label = CType(e.Item.FindControl("lblEmptyDataClosed"), Label)
        'lblFooter.Visible = True
        'End If
        'End If

    End Sub
End Class
