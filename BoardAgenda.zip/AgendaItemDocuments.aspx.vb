Imports System.Data.SqlClient
Imports System.Data
'Imports System.IO

Partial Class AgendaItemDocuments
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ErrInfo As String = ""
        Dim sPath As String
        Dim sPDF As String
        Dim iAgendaReportID As Integer
        Dim iRandomFileName As Integer

        If Not Page.IsPostBack Then
            Try
                sPDF = ""
                If Not Request("AgendaReportID") = Nothing Then
                    iAgendaReportID = Request.QueryString("AgendaReportID")
                    If Request("IsBoard") = Nothing Then
                        sSQL = "SELECT * FROM vwAgendaDocumentsTreeView "
                    Else
                        sSQL = "SELECT * FROM vwAgendaDocumentsBoardTreeView "
                    End If
                    sSQL = sSQL & "WHERE AgendaReportID = " & iAgendaReportID & " Order by DisplayOrder"
                    sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
                    Dim oConn As New SqlConnection(sConn)
                    Dim oComm As New SqlCommand(sSQL, oConn)
                    oComm.CommandType = CommandType.Text

                    oConn.Open()

                    Dim dr As SqlDataReader
                    dr = oComm.ExecuteReader()

                    sPath = System.Configuration.ConfigurationManager.AppSettings("PDFDocFilePath")
                    If Not Request("Transmittal") = Nothing Then
                        sPDF = sPath & iAgendaReportID & "_Transmittal.pdf+"
                    End If
                    'Check each field for null values 
                    Do While dr.Read()
                        sPDF = sPDF & "" & sPath & iAgendaReportID & "_" & dr("DisplayName") & ".pdf+"
                    Loop
                    sPDF = Left(sPDF, (Len(sPDF) - 1))
                End If

                If sPDF = "" Then Exit Sub

                Dim NVmerge As New Neevia.PDFmerge
                NVmerge.Linearize = True
                NVmerge.CreateNewBookmarks = True
                NVmerge.CreatePageBookmarks = True
                sPath = System.Configuration.ConfigurationManager.AppSettings("MergedPDFFilePath")
                iRandomFileName = RandomNumber()
                sPath = sPath & iRandomFileName & ".pdf"
                NVmerge.MergePDF(sPDF, sPath)
                'Dim theFile As New FileInfo(sPath)
                'Response.Write(theFile.Length.ToString())
                Response.Redirect("~/AgendaPDF/" & iRandomFileName & ".pdf")
            Catch Ex As Exception
                ErrInfo = Ex.Message
                Response.Write(Ex.Message)
            End Try
        End If
    End Sub

    Public Function RandomNumber() As Integer
        Dim MaxNumber As Integer = 9999
        Dim MinNumber As Integer = 1000

        'initialize random number generator
        Dim r As New Random(System.DateTime.Now.Millisecond)

        'if passed incorrect arguments, swap them
        'can also throw exception or return 0

        If MinNumber > MaxNumber Then
            Dim t As Integer = MinNumber
            MinNumber = MaxNumber
            MaxNumber = t
        End If

        Return r.Next(MinNumber, MaxNumber)

    End Function
End Class
