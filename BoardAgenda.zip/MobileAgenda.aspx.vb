Imports System.Data.SqlClient
Imports System.Data

Partial Class MobileAgenda
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String
    Dim sPath As String = "http://www.octa.net/AgendaPDF/"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            LoadGrid()
        End If

    End Sub

    Protected Sub LoadGrid()

        sSQL = "SELECT [CommitteeMeetingID], "
        sSQL = sSQL & "[CommitteeMeetingDate], "
        sSQL = sSQL & "CASE WHEN [CommitteeMeetingCancelled] = 1 THEN 'CANCELLED' END AS Cancelled, "
        sSQL = sSQL & "CommitteeMeetingType, "
        sSQL = sSQL & "'" & sPath & "' + RTRIM(CONVERT(char(5), CommitteeMeetingID)) + '_Synopsis.pdf' AS Synopsis, "
        sSQL = sSQL & "CONVERT(char(10), CommitteeMeetingDate, 101) + '-' + CommitteeMeetingType AS CommitteeMeeting "
        sSQL = sSQL & "FROM [vwCommitteeMeetingDates] "
        sSQL = sSQL & "ORDER BY CommitteeMeetingDate DESC"
        txtSQL.Text = sSQL

        Try

            'Set the parameter values
            sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
            Dim oConn As New SqlConnection(sConn)

            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.StoredProcedure

            oConn.Open()

            Dim oAdapter As New SqlDataAdapter(sSQL, oConn)
            Dim oDataSet As New DataSet
            oAdapter.Fill(oDataSet, "dtRecordList")

            Dim RcdCount As String
            RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

            If RcdCount = 0 Then
                GridView1.Visible = False
            Else
                GridView1.Visible = True
                GridView1.DataSource = oDataSet.Tables.Item("dtRecordList")
                GridView1.DataBind()
            End If

            oConn.Close()
            oComm = Nothing

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try

    End Sub
    Sub GridPageChange(ByVal sender As Object, ByVal e As GridViewPageEventArgs)

        'Function used to page datagrid
        GridView1.PageIndex = e.NewPageIndex

        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")
        Dim oConn As New SqlConnection(sConn)

        oConn.Open()

        'Use the SQL staement stored in the txtSQL textbox
        Dim oAdapter As New SqlDataAdapter(txtSQL.Text, oConn)
        Dim oDataSet As New DataSet
        oAdapter.Fill(oDataSet, "dtRecordList")

        Dim RcdCount As String
        RcdCount = oDataSet.Tables("dtRecordList").Rows.Count.ToString()

        If RcdCount = 0 Then
            GridView1.Visible = False
        Else
            GridView1.Visible = True
            GridView1.DataSource = oDataSet.Tables.Item("dtRecordList")
            GridView1.DataBind()
        End If

    End Sub
    Private Sub SortGrid(ByVal sSortField As String)

        'Sort function used to sort the data in the datagrid
        sConn = System.Configuration.ConfigurationManager.AppSettings("ConnStr")

        Dim DS As DataSet
        Dim oReader As SqlDataAdapter

        oReader = New SqlDataAdapter(txtSQL.Text, sConn)

        DS = New DataSet
        oReader.Fill(DS, "LoadRecords")

        Dim Source As DataView = DS.Tables("LoadRecords").DefaultView
        Source.Sort = sSortField

        GridView1.DataSource = Source
        GridView1.DataBind()

    End Sub

    Protected Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        Dim sStr As String = ""

        Try
            If e.Row.RowType = DataControlRowType.DataRow Then
                If e.Row.Cells(4).Text = "CANCELLED" Then
                    e.Row.Enabled = False
                End If
            End If

        Catch ex As Exception
            Console.WriteLine(ex.Source)
            Console.WriteLine(ex.Message)
            Console.WriteLine(ex.StackTrace)
            Console.WriteLine(ex.HelpLink)
        End Try
    End Sub

    Protected Sub GridView1_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles GridView1.Sorting

        SortGrid(e.SortExpression)

    End Sub
End Class
