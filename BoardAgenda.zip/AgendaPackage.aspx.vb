Imports System.IO
Partial Class AgendaPackage
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ErrInfo As String = ""
        Dim sPath As String
        Dim iRandomFileName As Integer

        If Not Page.IsPostBack Then
            Try
                Dim NVmerge As New Neevia.PDFmerge
                NVmerge.Linearize = True
                NVmerge.CreateNewBookmarks = True
                NVmerge.CreatePageBookmarks = True
                sPath = System.Configuration.ConfigurationManager.AppSettings("MergedPDFFilePath")
                iRandomFileName = RandomNumber()
                sPath = sPath & iRandomFileName & ".pdf"
                NVmerge.MergePDF(GetFileContents(), sPath)
                Response.Redirect("~/AgendaPDF/" & iRandomFileName & ".pdf")
            Catch Ex As Exception
                ErrInfo = Ex.Message
                Response.Write(Ex.Message)
            End Try
        End If
    End Sub

    Public Function GetFileContents(Optional ByRef ErrInfo As String = "") As String

        Dim strContents As String
        Dim objReader As StreamReader
        Dim sPath As String

        Try
            sPath = System.Configuration.ConfigurationManager.AppSettings("MergeFilePath")
            objReader = New StreamReader(sPath)
            strContents = objReader.ReadToEnd()
            objReader.Close()
            GetFileContents = strContents
        Catch Ex As Exception
            ErrInfo = Ex.Message
        End Try

    End Function

    Public Function RandomNumber() As Integer
        Dim MaxNumber As Integer = 10000
        Dim MinNumber As Integer = 1000

        'initialize random number generator
        Dim r As New Random(System.DateTime.Now.Millisecond)

        'if passed incorrect arguments, swap them
        'can also throw exception or return 0

        If MinNumber > MaxNumber Then
            Dim t As Integer = MinNumber
            MinNumber = MaxNumber
            MaxNumber = t
        End If

        Return r.Next(MinNumber, MaxNumber)

    End Function
End Class
